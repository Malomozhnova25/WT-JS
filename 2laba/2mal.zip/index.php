<html>
<head> <title> 2</title> </head>
<body align="center">
<h1>Лабораторная работа № 2 Маломожнова В.М. ПИ-323</h1><p>
<u1>
        <li><a href="http://a0673554.xsph.ru/2/2-1.html"> 1 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-2.html"> 2 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-3.html"> 3 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-4.html"> 4 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-5.html"> 5 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-6.html"> 6 упражнение</a></li>
        <li><a href="http://a0673554.xsph.ru/2/2-7.html"> 7 упражнение</a></li>
</u1>
</html>